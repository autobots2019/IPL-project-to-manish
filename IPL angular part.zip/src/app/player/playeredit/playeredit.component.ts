import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Player } from 'src/app/player';

@Component({
  selector: 'app-playeredit',
  templateUrl: './playeredit.component.html',
  styleUrls: ['./playeredit.component.css']
})
export class PlayereditComponent implements OnInit {
 
  player: Player=new Player();
  submitted = false;

  board: Object;
  errorMessage: string;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getUserBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }


  updatePlayer(playerAddress:string,matchesPlayed:number,strikeRate:number,average:number,playerRank:number){
console.log("player edit");

    this.userService.updatePlayer(this.player.playerId,
      { playerAddress:playerAddress,matchesPlayed:matchesPlayed,strikeRate:strikeRate,average:average,playerRank:playerRank })
      .subscribe(
        data => {
          console.log(data);
          this.player = data as Player;
        },
        error => console.log(error));
  }


 


}

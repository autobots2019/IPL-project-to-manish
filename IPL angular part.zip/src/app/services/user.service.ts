import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private userUrl = 'http://localhost:8080/api/players/user';
  private pmUrl = 'http://localhost:8080/api/test/pm';
  private adminUrl = 'http://localhost:8080/api/test/admin';
  private pmUserUrl = 'http://localhost:8080/api/players/all';

  constructor(private http: HttpClient) { }



  getPmUserBoard(): Observable<Object> {
    return this.http.get(this.pmUserUrl, { responseType: 'json' });
  }

  getUserBoard(): Observable<Object> {
    return this.http.get(this.userUrl, { responseType: 'json' });
  }
  getOwnerBoard(): Observable<Object> {
    return this.http.get(this.pmUrl, { responseType: 'json' });
  }


  getPMBoard(): Observable<string> {
    return this.http.get(this.pmUrl, { responseType: 'text' });
  }

  getAdminBoard(): Observable<Object> {
    return this.http.get(this.adminUrl, { responseType: 'json' });
  }
  
  getTeamList():Observable<any>{
    return this.http.get(`${this.adminUrl}`);
  }

  createPlayer(player: Object): Observable<Object> {
    return this.http.post(this.userUrl+`/create`, player);
     }
  
  acceptPlayer(players:Object): Observable<Object> {
    console.dir(players);
    return this.http.post(this.pmUrl+`/accept`, players);
  }
  deletePlayer(playerId: any): Observable<Object> {
    console.log(`${this.pmUrl}/delete/${playerId}`);
    return this.http.delete(`${this.pmUrl}/delete/${playerId}`);
    
  }
  
updatePlayer(id: number,value:any): Observable<Object> {
  return this.http.put(`${this.userUrl}/update/${id}`,value);
}
}

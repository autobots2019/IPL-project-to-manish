package com.ipl.jwtauthentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.SelectedPlayers;
import com.ipl.jwtauthentication.security.services.SelectedPlayerService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/owners/pm")
public class SelectedPlayerController {
	@Autowired
	SelectedPlayerService service;

	@PostMapping("/accept")
	public SelectedPlayers save(@RequestBody Player player) {
		System.out.println("player ---> "+player);
		SelectedPlayers selectedPlayers = new SelectedPlayers();
		selectedPlayers.setSelectedPlayerId(player.getPlayerId());
		return service.save(selectedPlayers);
	}
}

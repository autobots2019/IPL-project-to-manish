package com.ipl.jwtauthentication.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ipl.jwtauthentication.model.Teams;
import com.ipl.jwtauthentication.model.User;

@Repository
public interface TeamRepository extends JpaRepository<Teams, Long>{
	 
	    List<Teams>	findAll();
}

package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Teams;
@Service
public interface TeamDetailService extends UserDetailsService{
	List<Teams>	findAll();
}

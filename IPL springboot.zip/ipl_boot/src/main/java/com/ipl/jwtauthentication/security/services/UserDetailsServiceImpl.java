package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ipl.jwtauthentication.model.Teams;
import com.ipl.jwtauthentication.model.User;
import com.ipl.jwtauthentication.repository.TeamRepository;
import com.ipl.jwtauthentication.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements TeamDetailService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	TeamRepository teamRepository;

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		User user = userRepository.findByUsername(username).orElseThrow(
				() -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));

		return UserPrinciple.build(user);
	}

	@Override
	public List<Teams> findAll() {
		return teamRepository.findAll();
	}
}
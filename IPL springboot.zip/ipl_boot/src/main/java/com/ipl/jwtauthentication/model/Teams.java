package com.ipl.jwtauthentication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="teams")
public class Teams {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long teamId;
	
	@Column(name="teamName")
	private String teamName;

	public Teams() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Teams(long teamId, String teamName) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
	}

	public long getTeamId() {
		return teamId;
	}

	public void setTeamId(long teamId) {
		this.teamId = teamId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	@Override
	public String toString() {
		return "Teams [teamId=" + teamId + ", teamName=" + teamName + "]";
	}
	
	
	
	
}

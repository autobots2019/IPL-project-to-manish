package com.ipl.jwtauthentication.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "owners")
public class Owner {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;

    @NotBlank
    @Size(min=3, max = 50)
    private String ownerName;

    @NotBlank
    @Size(min=3, max = 50)
    private String ownerEmail;
    
    @NotBlank
    @Size(min=3, max = 50)
    private String ownerAddress;
    
    
    @NotBlank
    @Size(min=3, max = 50)
	private long ownerMobileNo;
    
    @NotBlank
    @Size(min=3, max = 50)
    private String ownerTeamName;
    
    @NotBlank
    @Size(min=3, max = 50)
    private String teamDesc;

	public Owner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Owner(Long ownerId, @NotBlank @Size(min = 3, max = 50) String ownerName,
			@NotBlank @Size(min = 3, max = 50) String ownerEmail,
			@NotBlank @Size(min = 3, max = 50) String ownerAddress,
			@NotBlank @Size(min = 3, max = 50) long ownerMobileNo,
			@NotBlank @Size(min = 3, max = 50) String ownerTeamName,
			@NotBlank @Size(min = 3, max = 50) String teamDesc) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownerEmail = ownerEmail;
		this.ownerAddress = ownerAddress;
		this.ownerMobileNo = ownerMobileNo;
		this.ownerTeamName = ownerTeamName;
		this.teamDesc = teamDesc;
	}

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerAddress() {
		return ownerAddress;
	}

	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}

	public long getOwnerMobileNo() {
		return ownerMobileNo;
	}

	public void setOwnerMobileNo(long ownerMobileNo) {
		this.ownerMobileNo = ownerMobileNo;
	}

	public String getOwnerTeamName() {
		return ownerTeamName;
	}

	public void setOwnerTeamName(String ownerTeamName) {
		this.ownerTeamName = ownerTeamName;
	}

	public String getTeamDesc() {
		return teamDesc;
	}

	public void setTeamDesc(String teamDesc) {
		this.teamDesc = teamDesc;
	}

	@Override
	public String toString() {
		return "Owner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerEmail=" + ownerEmail
				+ ", ownerAddress=" + ownerAddress + ", ownerMobileNo=" + ownerMobileNo + ", ownerTeamName="
				+ ownerTeamName + ", teamDesc=" + teamDesc + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ownerAddress == null) ? 0 : ownerAddress.hashCode());
		result = prime * result + ((ownerEmail == null) ? 0 : ownerEmail.hashCode());
		result = prime * result + ((ownerId == null) ? 0 : ownerId.hashCode());
		result = prime * result + (int) (ownerMobileNo ^ (ownerMobileNo >>> 32));
		result = prime * result + ((ownerName == null) ? 0 : ownerName.hashCode());
		result = prime * result + ((ownerTeamName == null) ? 0 : ownerTeamName.hashCode());
		result = prime * result + ((teamDesc == null) ? 0 : teamDesc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Owner other = (Owner) obj;
		if (ownerAddress == null) {
			if (other.ownerAddress != null)
				return false;
		} else if (!ownerAddress.equals(other.ownerAddress))
			return false;
		if (ownerEmail == null) {
			if (other.ownerEmail != null)
				return false;
		} else if (!ownerEmail.equals(other.ownerEmail))
			return false;
		if (ownerId == null) {
			if (other.ownerId != null)
				return false;
		} else if (!ownerId.equals(other.ownerId))
			return false;
		if (ownerMobileNo != other.ownerMobileNo)
			return false;
		if (ownerName == null) {
			if (other.ownerName != null)
				return false;
		} else if (!ownerName.equals(other.ownerName))
			return false;
		if (ownerTeamName == null) {
			if (other.ownerTeamName != null)
				return false;
		} else if (!ownerTeamName.equals(other.ownerTeamName))
			return false;
		if (teamDesc == null) {
			if (other.teamDesc != null)
				return false;
		} else if (!teamDesc.equals(other.teamDesc))
			return false;
		return true;
	}
    
    

}
